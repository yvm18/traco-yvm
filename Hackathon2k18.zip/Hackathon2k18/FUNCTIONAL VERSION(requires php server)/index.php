<!DOCTYPE html>
<html class="no-js"> <!--<![endif]-->
    <head>
    	<!--background music -->
    	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
		
		<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>TRACO</title>
        <embed src="music.mp3" width="0" height="0" loop="false" autostart="false" hidden="true" />
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

		<link rel="author" href="https://plus.google.com/u/0/109859280204979591787/about"/>

         
		

        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">

        <script>alert("This page is in development phase  PRESS OK");</script>

        <script src="js/vendor/modernizr-2.7.1.min.js"></script>
        
<!--        
        <script type="text/javascript">$(window).on('scroll',function(){
        	 
        	
        		if($(window).scrollTop()) 
        		{
        			$('nav').addClass('black');
        			
        		}
        		else 
        		{
        			$('nav').removeClass('black');
        		}
        	})
        </script>
-->
        <style type="text/css">
			body {
				font-family: 'Open Sans', sans-serif;
			}
			.windows10{
				position: relative;
				top: 130px;
				left: 100px;
			}
		</style>

    </head>
    <body class="loading">
        
       	
       	<div id="preload">
	       	<img src="img/bcg_slide-1.jpg">
	       	<img src="img/bcg_slide-2.jpg">
	       	<img src="img/bcg_slide-3.jpg">
	       	<img src="img/bcg_slide-4.jpg">
       	</div>
<!-- NAVBAR TRANSPARENT AND STICKY -->
       	<div class="wrapper">
       		<nav>

       			<div class="logo"><img src="logo.ico">RACO</div>
       			<ul>
       				<li><a href="#slide-1">About Traco</a></li>
       				<li><a href="#slide-2">Launch ON</a></li>
       				<li><a href="#slide-3">Our Team</a></li>
       				<li><a class="active" href="#slide-4">Contact Us</a></li>
       			</ul>
       		</nav>
       	</div>

<!--_______________________________________________________________________________________________________________________________-->       	
       	
       	 
	        <section id="slide-1" class="homeSlide">
	        	<div class="bcg"
		        	data-center="background-position: 50% 0px;"
				    data-top-bottom="background-position: 50% -100px;"
				    data-anchor-target="#slide-1">
       			 
		        	<div class="hsContainer">
		        	   	<div class="hsContent"
							data-center="bottom: 300px; opacity: 1"
			                data-top="bottom: 1600px; opacity: 0"
			                data-anchor-target="#slide-1 h2">
			    		
				    		<h2>Traco is an app designed to change the way you travel to your school, college or workplace. Once Traco is installed on your device, it won't let you miss your buses and will save tons of time you waste waiting for it.
				    		
							
				    		</h2>

			    		</div>
			    		
			    			<iframe class="windows10" width="500" height="320"  align="left" src="https://www.youtube.com/embed/0UTS08s4ANY" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
			    		

						
		        	</div>
	        	</div>
		    </section>
		    
		    <section id="slide-2" class="homeSlide">
		    	<div class="bcg"
			    	data-center="background-position: 50% 0px;"
			        data-top-bottom="background-position: 50% -100px;"
			        data-bottom-top="background-position: 50% 100px;"
			        data-anchor-target="#slide-2">
		    	
			    	<div class="hsContainer">
				   		<div class="hsContent"
				    		data-center="opacity: 1"
			                data-center-top="opacity: 0"
			                data--100-bottom="opacity: 0;"
			                data-anchor-target="#slide-2">
			    		
				    		<h2>This section will show the countdown timer for the apps launch date.</h2>
			    		</div>
		        	</div>
		    	</div>
		    </section>
		    
			<section id="slide-3" class="homeSlide">
				<div class="bcg"
					data-center="background-position: 50% 0px;"
			        data-top-bottom="background-position: 50% -100px;"
			        data-bottom-top="background-position: 50% 100px;"
			        data-anchor-target="#slide-3">
				
			    	<div class="hsContainer">
		    			<div class="hsContent"
		    				data--50-bottom="opacity: 0;"
			                data--200-bottom="opacity: 1;"
			                data-center="opacity: 1"
			                data-200-top="opacity: 0"
			                data-anchor-target="#slide-3 h2">
		    			
				    		<h2>Meet Our Teem Page.</h2>
			    		</div>
			    	</div>
			    	
			    </div>
			</section>
			
			<section id="slide-4" class="homeSlide">
				<div class="bcg"
					data-center="background-position: 50% 0px;"
			        data-top-bottom="background-position: 50% -100px;"
			        data-bottom-top="background-position: 50% 100px;"
			        data-anchor-target="#slide-4">
				
			    	<div class="hsContainer">
		    			<div class="hsContent"
		    				data-bottom-top="opacity: 0"
			                data-25p-top="opacity: 0"
			                data-top="opacity: 1" 
			                data-anchor-target="#slide-4">
		    			
				    		<h2>Wanna discover more... This section will contain team Traco's contact details plus a map showing the location of the office</h2>
			    								     
						 </div>
			    	</div>
			    	 <div class="register">
			    	 	<form style="text-align: center;"  method="POST" enctype="multipart/form-data">
						         <h2>Message US!</h2>
						         <div class="form-group row">
						         	<label for="name" class="col-sm-2 col-form-label">Name</label>
						       		<div class="col-sm-9">
						             <input type="text" class="form-control" id="name" name="name" required>
						            </div>
						         </div>
						         
						         <div class="form-group row">
						           <label for="email" class="col-sm-2 col-form-label">Email ID</label>
						           <div class="col-sm-9">
						             <input type="email" class="form-control" id="email"  name="email" required>
						           </div>
						         </div>
						         <div class="form-group row">
						         	<label for="commnets" class="col-sm-2 col-form-label"><br>Comments</label>
						         	<div class="col-sm-9">
						         		<textarea name="comments" id="comments"  style="height: 90px; width: 520px; border-radius: .25rem; font-family: cursive;" required></textarea>
						         	</div>
						         </div><br>
						         <div class="buttons">
          							<button type="submit" class="btn btn-primary">Submit</button>&nbsp;&nbsp;&nbsp;
          							<button type="reset" class="btn btn-primary">Reset</button>
         						</div>      
						</form>

					 </div>
						        
						         
						        
						         
					
						     <br><br>
			    	
			    </div>
			</section>
		    
		

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.9.1.min.js"><\/script>')</script>
        <script src="js/imagesloaded.js"></script>
        <script src="js/skrollr.js"></script>
        <script src="js/_main.js"></script>

        <script type="text/javascript">
      
	     $("form").submit(function (e){
	      e.preventDefault();
	      
	      var error ="";

	      if($("#name").val()==""){
	        error += "<p>Name field is required.</p>"
	      }
	      
	      if($("#email").val()==""){
	        error += "<p>Email field is required.</p>"
	      }
	      if($("#comments").val()==""){
	        error += "<p>Please write something.</p>"
	      }
	      
	      if (error != "") {

	        $("#error").html('<div class="alert alert-danger" role="alert">There were some error(s) in your form: ' + error +'</div>');

	      } else {

	        $("form").unbind("submit").submit(); 
	      }

	     });

	   </script>

    </body>
</html>




<!--PHP to insert the details in the database -->



<?php
	if(isset($_POST['name']))
	{
	$name = $_POST['name'];
	}
	if(isset($_POST['email']))
	{
	$email = $_POST['email'];
	}
	if(isset($_POST['comments']))
	{
		$comments = $_POST['comments'];	
	}
	if( !empty($name) || !empty($email) || !empty($comments) )
	{
		$host="localhost";
		$dbUsername="root";
		$dbPassword="";
		$dbname="traco";
		
		//create connection
		$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
		if (mysqli_connect_error())
		{
			die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
		}
		else
		{
			$SELECT = "SELECT id From register Where id = ? Limit 1";
			$INSERT = "INSERT Into register(name, email, comments) values(?, ?, ?)";
			
			//prepare statement
			$stmt = $conn->prepare($SELECT);
			$stmt->bind_param("i", $id);
			$stmt->execute();
			$stmt->bind_result($id);
			$stmt->store_result();
			$rnum = $stmt->num_rows;
			
			if($rnum==0)
			{
		    	$stmt->close();
				$stmt = $conn->prepare($INSERT);
				$stmt->bind_param("sss", $name, $email, $comments);
				$stmt->execute();
				
				
    			echo '<html>
                    <head>
                        <script type = "text/javascript" >
        
                            function preventBack(){window.history.forward();}
            
                            setTimeout("preventBack()", 0);
            
                            window.onunload=function(){null};
        
                        </script>
               
                       ';
                
			}
			
			$stmt->close();
			$conn->close();
		}
		
		
	}
	
?>