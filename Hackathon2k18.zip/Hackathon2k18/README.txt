



This .zip file contains two versions of the website.

One is the Front-End only version which isn't connected to any sort of database but is for giving a basic idea of what our website will look like.

Second one is the functional version of the website which is contains the php code required to connect to a database. However you will 
need a server supporting php7 and higher.


PLEASE USE THE SUPPORTED BROWSERS AND DEVICES ONLY in maximum window size.

SUPPORTED BROWSERS : latest version of Google Chrome or Firefox
SUPPORTED DEVICES  : laptops or pc (does not supported mobile phones and tablets yet.) 





--------------------------------------------------------------------------------THANK YOU--------------------------------------------------------------------------------------