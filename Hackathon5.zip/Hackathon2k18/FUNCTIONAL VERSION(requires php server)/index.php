<!DOCTYPE html>
<html class="no-js"> <!--<![endif]-->
    <head>
    	<!--Fontawesome CDN -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
    	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
		
		<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>TRACO</title>
        <embed src="music.mp3" width="0" height="0" loop="false" autostart="false" hidden="true" />
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

		<link rel="author" href="https://plus.google.com/u/0/109859280204979591787/about"/>
	<!--Slider for Meet out Team section-->
	<link rel="stylesheet" href="ism/css/my-slider.css"/>
	<script src="ism/js/ism-2.2.min.js"></script>

	<!--Fontawesome CDN -->
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">


         
		

        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">

        
        <script src="js/vendor/modernizr-2.7.1.min.js"></script>
        
<!--        
        <script type="text/javascript">$(window).on('scroll',function(){
        	 
        	
        		if($(window).scrollTop()) 
        		{
        			$('nav').addClass('black');
        			
        		}
        		else 
        		{
        			$('nav').removeClass('black');
        		}
        	})
        </script>
-->
        <style type="text/css">
			body {
				font-family: 'Open Sans', sans-serif;
			}
			.windows10{
				position: relative;
				top: 130px;
				left: 100px;
			}
		</style>

    </head>
    <body class="loading">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
       	
       	<div id="preload">
	       	<img src="img/bcg_slide-1.jpg">
	       	<img src="img/bcg_slide-2.jpg">
	       	<img src="img/bcg_slide-3.jpg">
	       	<img src="img/bcg_slide-4.jpg">
       	</div>
<!-- NAVBAR TRANSPARENT AND STICKY -->
       	<div class="wrapper" style="max-height: 100%; max-width: 100%; min-width: 100%; min-height: 100;">
       		<nav style="max-height: 100%; max-width: 100%; min-width: 100%; min-height: 100;">

       			<div class="logo"><img src="logo.ico" ></div>
       			<ul>
       				<li><a href="#slide-1" style="max-height: 100%; max-width: 100%; min-width: 100%; min-height: 100;"><b>About Traco</b></h2></a></li>
       				<li><a href="#slide-2" style="max-height: 100%; max-width: 100%; min-width: 100%; min-height: 100;"><b>Launch ON</b></a></li>
       				<li><a href="#slide-3" style="max-height: 100%; max-width: 100%; min-width: 100%; min-height: 100;"><b>Our Team</b></a></li>
       				<li><a class="active" href="#slide-4" style="max-height: 100%; max-width: 100%; min-width: 100%; min-height: 100;"><b>Contact Us</b></a></li>
       			</ul>
       		</nav>
       	</div>

<!--_______________________________________________________________________________________________________________________________-->       	
       	
       	 
	        <section id="slide-1" class="homeSlide">
	        	<div class="bcg"
		        	data-center="background-position: 50% 0px;"
				    data-top-bottom="background-position: 50% -100px;"
				    data-anchor-target="#slide-1">
       			 
		        	<div class="hsContainer">
		        	   	<div class="hsContent"
							data-center="bottom: 300px; opacity: 1"
			                data-top="bottom: 1600px; opacity: 0"
			                data-anchor-target="#slide-1 h2">
			    		
				    		<h2>Traco is an app designed to change the way you travel to your school, college or workplace. Once Traco is installed on your device, it won't let you miss your buses and will save tons of time you waste waiting for it. <a href="about.docx">Click</a> for a detailed description.
				    		
							
				    		</h2>

			    		</div>
			    		
			    			<iframe class="windows10" width="500" height="320"  align="left" src="https://www.youtube.com/embed/0UTS08s4ANY" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen ></iframe>
			    		

						
		        	</div>
	        	</div>
		    </section>
		    
		    <section id="slide-2" class="homeSlide">
		    	<div class="bcg"
			    	data-center="background-position: 50% 0px;"
			        data-top-bottom="background-position: 50% -100px;"
			        data-bottom-top="background-position: 50% 100px;"
			        data-anchor-target="#slide-2">
		    	
			    	<div class="hsContainer">
				   		<div class="hsContent"
				    		data-center="opacity: 1"
			                data-center-top="opacity: 0"
			                data--100-bottom="opacity: 0;"
			                data-anchor-target="#slide-2">
			    		
				    		<h2>This section will show the countdown timer for the app's launch date.</h2>
			    		</div>
		        	</div>
		    	</div>
		    </section>
		    
			<section id="slide-3" class="homeSlide">
				<div class="bcg"
				data-center="background-position: 50% 0px;"
			        data-top-bottom="background-position: 50% -100px;"
			        data-bottom-top="background-position: 50% 100px;"
			        data-anchor-target="#slide-3">
					<div class="hsContainer">
						<div class="hsContent" 
							data--50-bottom="opacity: 0;"
			                data--200-bottom="opacity: 1;"
			                data-center="opacity: 1"
			                data-200-top="opacity: 0"
			                data-anchor-target="#slide-3 ">                    
			               
			            </div>

			             <h1><b><center>Our Team</center></b></h1>
			                

			    		<div class="wrap">
			    			<div class="column">
			    				<div class="imgBx">
			    					<img src="1.jpg" style="width: 100%">
			    				</div>
			    				<div class="details">
			    					<div class="content">
			    						<h1>Himanshu<br><span>Web-Developer</span></h1>
			    						<ul>
				    						<li><a href="https://www.facebook.com/himanshu9xm"><i class="fab fa-facebook"></i></a></li>
				    						<li><a href="https://www.instagram.com/himanshu9xm"><i class="fab fa-instagram"></i></a></li>
				    						<li><a href="#"><i class="fab fa-twitter-square"></i></a></li>

			    						</ul>
			    					</div>
			    					
			    				</div>
			    			</div>
			    			<div class="column">
			    				<div class="imgBx">
			    					<img src="2.jpg" style="width: 100%">
			    				</div>
			    				<div class="details">
			    					<div class="content">
			    						<h1>Bharat<br><span>Marketing Manager</span></h1>
			    						<ul>
				    						<li><a href="https://www.facebook.com/"><i class="fab fa-facebook"></i></a></li>
				    						<li><a href="https://www.instagram.com/agarwal3625"><i class="fab fa-instagram"></i></a></li>
				    						<li><a href="#"><i class="fab fa-twitter-square"></i></a></li>
			    						</ul>
			    					</div>
			    					
			    				</div>
			    			</div>
			    			<div class="column">
			    				<div class="imgBx">
			    					<img src="3.jpg" style="width: 100%">
			    				</div>
			    				<div class="details">
			    					<div class="content">
			    						<h1>Yash<br><span>App-Developer</span></h1>
			    						<ul>
				    						<li><a href="#"><i class="fab fa-facebook"></i></a></li>
				    						<li><a href="#"><i class="fab fa-instagram"></i></a></li>
				    						<li><a href="#"><i class="fab fa-twitter-square"></i></a></li>
			    						</ul>
			    					</div>
			    					
			    				</div>
			    			</div>
			    			<div class="column">
			    				<div class="imgBx">
			    					<img src="4.jpg" style="width: 100%">
			    				</div>
			    				<div class="details">
			    					<div class="content">
			    						<h1>Sanyam<br><span>Developer</span></h1>
			    						<ul>
				    						<li><a href="https://www.facebook.com/sanayamshah105"><i class="fab fa-facebook"></i></a></li>
				    						<li><a href="https://www.instagram.com/iamsnty"><i class="fab fa-instagram"></i></a></li>
				    						<li><a href="#"><i class="fab fa-twitter-square"></i></a></li>
			    						</ul>
			    					</div>
			    					
			    				</div>
			    			</div>
			    		</div>
			    	</div>
			    </div>

			    	

			    	

							


			    		
			</section>
			
			<section id="slide-4" class="homeSlide">
				<div class="bcg"
					data-center="background-position: 50% 0px;"
			        data-top-bottom="background-position: 50% -100px;"
			        data-bottom-top="background-position: 50% 100px;"
			        data-anchor-target="#slide-4">
				
			    	<div class="hsContainer">
		    			<div class="hsContent">
		    				<div class="contact"
			    				data-bottom-top="opacity: 0"
				                data-25p-top="opacity: 0"
				                data-top="opacity: 1" 
				                data-anchor-target="#slide-4" h2>
			    			
					    		<center><h2><h1>Call us   @ 91-9876543210 
				    			<center>OR</center>
				    			E-mail us @ himanshu9xm@gmail.com</h1></h2>
				    			 
				    			</center>
				    		</div>
						 </div>
						 	

			    	</div>
			    	 <div class="register">
			    	 	<form style="text-align: center;"  method="POST" enctype="multipart/form-data">
						         <h2>Message Us!</h2>
						         <div class="form-group row">
						         	<label for="name" class="col-sm-2 col-form-label">Name</label>
						       		<div class="col-sm-9">
						             <input type="text" class="form-control" id="name" name="name" required>
						            </div>
						         </div>
						         
						         <div class="form-group row">
						           <label for="email" class="col-sm-2 col-form-label">Email ID</label>
						           <div class="col-sm-9">
						             <input type="email" class="form-control" id="email"  name="email" required>
						           </div>
						         </div>
						        <!-- <div class="form-group row">
						         	<label for="checkid"  style="word-wrap:break-word">
								        <input id="checkid"  type="checkbox" value="test" />Register for Newsletter
								    </label>
						         </div>
						         -->
						         <div class="form-group row">
						         	<label for="commnets" class="col-sm-2 col-form-label"><br>Comments</label>
						         	<div class="col-sm-9">
						         		<textarea name="comments" id="comments" placeholder="Keep it short, sweet and simple :) " style="height: 90px; width: 520px; border-radius: .25rem; font-family: cursive; position: relative; max-width: 100%; max-height: 100%; min-height: 100%; min-width: 100%;" required></textarea>
						         	</div>
						         </div>

						         <br>
						         <div class="buttons">
          							<button type="submit" class="btn btn-primary">Submit</button>&nbsp;&nbsp;&nbsp;
          							<button type="reset" class="btn btn-primary">Reset</button>
         						</div>      
						</form>

					 </div>
						        
						         
						        
						         
					
						     <br><br>
			    	
			    </div>
			</section>
		    
		

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.9.1.min.js"><\/script>')</script>
        <script src="js/imagesloaded.js"></script>
        <script src="js/skrollr.js"></script>
        <script src="js/_main.js"></script>

        <script type="text/javascript">
      
	     
    </body>
</html>




<!--PHP to insert the details in the database -->



<?php
	if(isset($_POST['name']))
	{
		$name = $_POST['name'];
	}
		if(isset($_POST['email']))
	{
		$email = $_POST['email'];
	}
		if(isset($_POST['comments']))
	{
		$comments = $_POST['comments'];	
	}
	if( !empty($name) || !empty($email) || !empty($comments) )
	{
		$host="localhost";
		$dbUsername="root";
		$dbPassword="";
		$dbname="traco";
		
		//create connection
		$conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
		if (mysqli_connect_error())
		{
			die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
		}
		else
		{
			$SELECT = "SELECT id From register Where id = ? Limit 1";
			$INSERT = "INSERT Into register(name, email, comments) values(?, ?, ?)";
			
			//prepare statement
			$stmt = $conn->prepare($SELECT);
			$stmt->bind_param("i", $id);
			$stmt->execute();
			$stmt->bind_result($id);
			$stmt->store_result();
			$rnum = $stmt->num_rows;
			
			if($rnum==0)
			{
		    	$stmt->close();
				$stmt = $conn->prepare($INSERT);
				$stmt->bind_param("sss", $name, $email, $comments);
				$stmt->execute();
				
				
    			echo '<html>
                    <head>
                        <script type = "text/javascript" >
        
                            function preventBack(){window.history.forward();}
            
                            setTimeout("preventBack()", 0);
            
                            window.onunload=function(){null};
        
                        </script>

                         <meta http-equiv="refresh" content="2;url=index" />
                         </head>
                         </html>
               
                       ';

                
			}
			
			$stmt->close();
			$conn->close();
		}
		
		
	}
	
?>